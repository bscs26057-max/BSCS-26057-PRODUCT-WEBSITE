window.onload = function() {
    alert("Welcome to VELOURE!");

    var year = document.getElementById("year");
    if (year) {
        year.innerHTML = new Date().getFullYear();
    }
};

function showStock(button) {
    var stock = button.nextElementSibling;

    if (stock.innerHTML == "") {
        stock.innerHTML = "In stock";
    } else {
        stock.innerHTML = "";
    }
}
